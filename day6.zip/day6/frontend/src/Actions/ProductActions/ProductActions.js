import { composeWithDevTools } from "@redux-devtools/extension";
import axios from "axios";
import { applyMiddleware, combineReducers, createStore } from "redux";


export const  productsdata=()=> async (dispatch)=>{
    try{
        dispatch({type:'PRODUCT_DATA_REQUESTED'})
        const products= await  axios.get("http://localhost:8001/ECON1/PRODUCTS");
        dispatch({type:'PRODUCT_DATA_SUCCESS',
    payload:products})

        } 
    catch(error){
        dispatch({type:'PRODUCT_DATA_FAIL',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})

    }
}
export const singleproductdata=({id})=>async(dispatch)=>{
try{
    const singleproduct= await axios.get(`http://localhost:8001/ECON1/PRODUCTS/${id}`)
    dispatch({type:'SINGLEPRODUCT_DATA_SUCCESS',payload:singleproduct})
}
catch(error){

}
}
