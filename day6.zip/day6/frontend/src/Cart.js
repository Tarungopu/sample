import React,{useEffect,useState} from 'react'
import { NavLink, useParams } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios"
import './Cart.css'
import { useDispatch, useSelector } from 'react-redux';
import { cartad ,cartdelete} from './Actions/CartAction/CartAction';

const Cart = () => {
  const{id}=useParams();
  console.log(id);
  const{qtyy}=useParams();
  console.log(qtyy)
const cart=useSelector((state)=>state.cartdata);
const{cartdata}=cart;
const allitems=  cart.cartitems
console.log(allitems)
const[total,setTotal]=useState(0)
  const dispatch=useDispatch()
  useEffect(() => {
   if(id){
     dispatch(cartad(id,qty))
     //passing the action id qty got from use params
   }
  
    
  }, [])
  const handleplusqty=(s)=>{

    dispatch(cartad(s.product,s.qty+1))

}

const handleminusqty=(s)=>{
const minusqty=(s.qty)-1;
const singleid=(s.product);
console.log(singleid);
dispatch(cartad(s.product,s.qty-1))
console.log(s.qty-1)

  }
  let r=0;
let d;
console.log(d);
const handledelete=(singlecartitem)=>{
  console.log(singlecartitem.product);
  dispatch(cartdelete(singlecartitem.product))
  toast('deleted')
}
 const display=(singlecartitem)=>(
   
      <div className="row gx-2">
        <div className="col-12">
        <div class="card my-3">

          <div className="row">
        <div className="col-2">

      {
  }
    <div className="card-img mx-2 ">
  <img src={singlecartitem.Img} style={{marginLeft:"20%"}}className="img-fluid" />
  </div>
  </div>
  <div className="col-4 ">


  <div class="card-body" >

<p>{singlecartitem.Name}</p>
    
    <p>₹{singlecartitem.Price}</p>

   {/* {
    console.log(singlecartitem)}
    <select value={qty} onChange={(e)=>dispatch(cartad(singlecartitem.product,Number(e.target.value)))}>
    {[...Array(singlecartitem.CountInstock).keys()].map((option)=>(
      <option key={option+1} value={option+1}>{option}</option>
    ))} 

    </select> */}
  </div>
  </div>
  <div className="col-4 mt-4">

<button className="btn btn-dark btn-sm mx-4 " onClick={()=>handleminusqty(singlecartitem)} disabled={singlecartitem.qty<=1}>-</button>
{singlecartitem.qty} 

<button className='btn btn-dark btn-sm mx-4 ' onClick={()=>handleplusqty(singlecartitem)} disabled={singlecartitem.qty===singlecartitem.CountInstock}>+</button>
</div>

<div className="col-2 " style={{marginTop:"30px"}}>
<i class='bx bxs-trash' onClick={()=>handledelete(singlecartitem)} style={{fontSize:"18px",cursor:"pointer"}}></i>
</div>
</div>
</div>
</div>

</div>
  )


const n=allitems.reduce((total,s)=>total+s.qty*s.Price,0)

  const{qty}=useParams();
  console.log(qty);
  const k=()=>{
    toast("Added to cart")
  }
  return (
    <>
        {allitems.length >0 ?(
    <div className="container">
              <NavLink to="/" className=" card_button mx-4 px-2 py-2" style={{textDecoration:"none"}}>Go back</NavLink>

      <div className="row mx-4 my-4">
<div className='col-6 '>
  <h4>Subtotal<span style={{color:"red"}}>₹{n}</span></h4>
   
</div>
<div className="col-4 ">
<h4><NavLink to="/" className='checkout' >Checkout</NavLink></h4>
{/* <NavLink to="/login?redirect=shopping">tu</NavLink> */}
</div>
</div>
<div className="row">

<div className="col-12 mx-3">

{
  allitems.map(singlecartitem=>

display(singlecartitem))
}

      <ToastContainer/>
      </div>


</div>

    </div>)
  :(
    <h1>Dude Seriously ,You want to see cart even though you know it's empty</h1>
  )}
 </>
 )
}

export default Cart