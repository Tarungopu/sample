import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Home from './Home';
import About from './About';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';
import Cart from './Cart';
import SingleProduct from './components/ProductCard/SingleProduct';

function App() {
  return (
    <>
    <div className='container1'style={{minHeight:"90vh"}} >
    <Router>
<Header/>
      <Routes>

        <Route path="/"  element={<ProductCard/>}/>
        <Route path="/signin" element={<About/>}/>
        <Route path="/cart" element={<Cart/>}>
          <Route path=":id/:qty" element={<Cart/>}/>
        </Route>

        <Route path="/products/:id" element={<SingleProduct/>}/>


      </Routes>
    </Router>

    </div>

        <Footer />
</>
  );
}

export default App;
