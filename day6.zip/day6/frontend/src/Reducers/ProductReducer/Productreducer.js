export const ProductDataReducer=(state={products:[]},action)=>{

    switch(action.type){
        case 'PRODUCT_DATA_REQUESTED':
            return {loading:true,products:[]}
            case 'PRODUCT_DATA_SUCCESS':
                return {loading:false,products:action.payload.data}
                case 'PRODUCT_DATA_FAIL':
                    return{loading:false,error:action.payload}
                    default:
                        return state
    }


}

export const singleproductreducer=(state={product:{reviews:[]}},action)=>{

    switch(action.type){
        case 'SINGLEPRODUCT_DATA_REQUESTED':
            return {loading:true,...state}
            case 'SINGLEPRODUCT_DATA_SUCCESS':
                return {loading:false,product:action.payload.data}
                case 'SINGLEPRODUCT_DATA_FAIL':
                    return{loading:false,error:action.payload}
                    default:
                        return state
    }


}
