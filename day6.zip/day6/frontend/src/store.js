import {createStore,combineReducers,applyMiddleware} from 'redux'
import thunk from 'redux-thunk';
import {composeWithDevTools} from '@redux-devtools/extension';
import {ProductDataReducer, singleproductreducer} from './Reducers/ProductReducer/Productreducer.js'
import { cartreducer } from './Reducers/CartReducer.js/Cartreducer.js';
const cartitemsfromstorage=localStorage.getItem('cartitems') ? JSON.parse(localStorage.getItem('cartitems')) :[]
const initialstate={

    cartdata:{cartitems:cartitemsfromstorage}
};
const reducers=combineReducers({
Productdata:ProductDataReducer,
Singleproductdata:singleproductreducer,
cartdata:cartreducer



});
const middleware=[thunk]

const store=createStore(reducers,initialstate,composeWithDevTools(applyMiddleware(...middleware)));


export default store;
