import React from 'react'
import {GoLocation} from 'react-icons/go'
import './index.css'

const Footer  =  () => {
  return (
<footer >
<div className="footer" >
    <div className="row-footer">
        <div className="col-12 col-lg-12 mx-auto col-xl-12 col-sm-12">
              <div className="row">
                  <div className="col-6 col-lg-3 col-md-6 col-sm-12">
                      <h2>Find a Store</h2>
                      <ul>
                          <li><a href="">BECOME A MEMBER</a></li>
                          <li><a href="">SIGN UP FOR EMAIL </a></li>
                          <li><a href="">STUDENT DISCOUNTS</a></li>
                          <li><a href="">SEND US FEEDBACK</a></li>
                      </ul>

                  </div>
                  <div className="col-6 col-lg-3 col-md-6 col-sm-12">
                      <h2>GET HELP</h2>
                      <ul>
                          <li><a href="">order status</a></li>
                          <li><a href="">Delivery</a></li>
                          <li><a href="">dPayment Options</a></li>
                          <li><a href="">Contact us on WWW.com inquiries</a></li>
                      </ul>

                  </div>
                  <div className="col-6 col-lg-3 col-md-6">
                      <h2>ABOUT NIKE</h2>
                      <ul>
                          <li><a href="">News</a></li>
                          <li><a href="">Careers</a></li>
                          <li><a href="">Investors</a></li>
                          <li><a href="">Sustainability</a></li>
                      </ul>

                  </div>
                  <div className="col-6 col-lg-3 col-md-6 col-sm-12  ">
                  <div className="row ">
                   <div className=" col-xl-12 col-sm-12 col-lg-12 col-md-12 icons">
                   <a href=""><i className='bx bxl-twitter'></i></a>

                          <a href=""> <i className='bx bxl-facebook'></i></a>
                        <a href=""><i className='bx bxl-youtube'></i></a>
                          <a href=""><i className='bx bxl-instagram' ></i></a>
                      </div>
                      </div>
                  </div>

           </div>
        </div>
    </div>
  
</div>
<div style={{marginBottom:"10px"}}>
           <hr />
<p  className='  text-center'> <span style={{color:"white"}}> <GoLocation style={{color:"white"}}/>India   </span> &copy;  Nike,All Rights Reserved
</p>
</div>

</footer>  )

}

export default  Footer