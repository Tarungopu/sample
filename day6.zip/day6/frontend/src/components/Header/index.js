import React,{useState} from 'react'
import { useSelector } from 'react-redux';
import {Link, useNavigate} from 'react-router-dom'
import './index.css'
const Header = () => {
  const cart=useSelector((state)=>state.cartdata);
  const{cartdata}=cart;
  const noofitems=  cart.cartitems.length;
  const navigate=useNavigate()

    const [show,setShow]=useState(false);
  const [value,setValue]=useState(0);
  const changeroute=()=>{
navigate("/cart")
  }
  const toggle=()=>{

    return setShow(!show);
  }
  return (
    <div className='container'>
 
      <div className="navbar">
        <div className="logo" style={{cursor:"pointer"}}>
          
          <span className="iconify" data-icon="simple-icons:nike" style={{color: "black"}}></span>
        <div className="bag" style={{cursor:"pointer"}} onClick={changeroute}>
          <i class='bx bx-shopping-bag ' style={{color:"black",fontSize:"22px",marginRight:"50px"}}>

          <p style={{fontSize:"18px",position:"absolute",right:"30px",top:"0%"}} >{noofitems}</p>
          </i>
          </div>  
        </div>
        <div className={show ? "links active" : "links"}>
        <Link onClick={()=>toggle()} to="/">Home</Link>
        <Link onClick={()=>toggle()}to="/cart">Cart <i class='bx bx-shopping-bag'><span class="badge badge-pill ">{noofitems}</span></i></Link>
        <Link onClick={()=>toggle()}to="/signin">Signin <i className='bx bx-user ' ></i></Link>
        <Link onClick={()=>toggle()}to="/about">about</Link>
        <button onClick={()=>setValue(value+1)}>click1</button>
        </div>
        <div className={show ?'bars-button active' : 'bars-button'} onClick={()=>toggle()}>
        <span></span>
        <span></span>
        <span></span>
        </div>
      </div>
 
    </div>
  )
}

export default Header