import mongoose from 'mongoose';
const Schema=mongoose.Schema;
const OrderSchema = new Schema({
    user:{
type:mongoose.Schema.Types.ObjectId,
required:true,
ref:'User'
    },

OrderedList:[
    {

        Name:{
            type:String,
            required:true,
        },
        Image:{
            type:String,
            required:true

        },
        Quantity:{
            type:Number,
            required:true

        },
        price:{
            type:Number,
            required:true
        },
        product:{
            type:mongoose.Schema.Types.ObjectId,
            ref:'Product',
            required:true
        }
    }
],
Address:{
    State:{type:String,required:true},
    Pincode:{type:String,required:true},
    City:{type:String,required:true},


},
payment:{
    type:'String',
    required:true
},
paymentoutcome:{
 id:{type:String},
 status:{type:String},
 recenttime:{type:String},
 email:{type:String},



},
tax:{
    type:'Number',
    required:true,
    
},
shippingprice:{
    type:'Number',
    required:true,
    
},
totalprice:{
    type:'Number',
    required:true,
    
},
IsPaid:{
    type:'Boolean',
    default:false,
    required:true
},
paiddate:{
    type:Date,
},
IsDelivered:{
    type:'Boolean',
    default:false,
    required:true
},
delivereddate:{
    type:Date,
}

},

{
    timestamps:true
}

)




const Order=mongoose.model("Order",OrderSchema);
module.exports=(Order);
