import mongoose from 'mongoose';
const Schema=mongoose.Schema;
const ReviewSchema = new Schema({

Name:{
    type:String,
    required:true,
    unique:true

},
Rating:{
    type:Number,
    required:true,
    unique:true
},
Comments:{
    type:String,
    required:true

},
 },
{
    timestamps:true
}

)


export default ReviewSchema;