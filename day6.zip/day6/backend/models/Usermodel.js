import mongoose from 'mongoose';
const Schema=mongoose.Schema;
import bcrypt from 'bcrypt'
// import dummy from 'mongoose-dummy';

const UserSchema = new Schema({

Name:{
    type:String,
    required:true,
    unique:true

},  
Email:{
    type:String,
    required:true,
    unique:true
},
Password:{
    type:String,
    required:true

},
IsAdmin:{
    type:Boolean,
default:false

} },
{
    timestamps:true
}

)

UserSchema.methods.matchPassword =async function(enteredPassword){
    const salt =await bcrypt.genSalt(10)
    const hashedpassword = await bcrypt.hash(this.Password,salt)
    this.Password=hashedpassword
    return await bcrypt.compare(enteredPassword,this.Password)

}
UserSchema.pre('save',async function(next){
    if(!this.isModified('password')){

        next()
    }
    const salt = await bcrypt.genSalt(10)
    this.Password=await bcrypt.hash(this.Password,salt)
})

const User=mongoose.model("User",UserSchema);
// let randomObject = dummy(User, {
//     returnDate: true
// })
// console.log(randomObject);
export default (User);
