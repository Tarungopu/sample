const products=[
    {
        name: "Nike shoes1",
        img:"/Images/img1.png",
        description:"The Nike React Metcon Turbo puts stability and responsiveness in a lightweight package ,to help you hit your next PB.From the cushioning underfoot to the rope wrap at the instep,every details is pareddown to minimise weight while maximising function and durability.Lighter,Stronger materials are built for speed and strength.",
        brand:"nike",
    category:"casuals",
        price:2000,
        offerprice:3200,
        countInStock:1,
        rating:4.3,
        numReviews:2

    },
   { 
    name: "Nike jordan shoes2",
    img:"/Images/img1.png",
    description:"The Nike React Metcon Turbo puts stability and responsiveness in a lightweight package ,to help you hit your next PB.From the cushioning underfoot to the rope wrap at the instep,every details is pareddown to minimise weight while maximising function and durability.Lighter,Stronger materials are built for speed and strength.",
    brand:"nike",
    category:"casuals",
    price:2000,
    offerprice:3400,
    countInStock:1,
    rating:2.3,
    numReviews:2
}]

export default products;