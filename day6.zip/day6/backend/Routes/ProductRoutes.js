import express from 'express';
const router=express.Router();
// import Product from '../models/Productmodel.js';
import {getProducts,getProductById,deleteProductById} from '../controllers/productController.js'
 
router.route('/').get(getProducts)
router.route('/:id').get(getProductById)
router.route('/delete/:id').delete(deleteProductById)



export default router;