import express from 'express';
const router=express.Router();
import Cart from '../models/Cartmodel.js'

router.get("/",async(req,res)=>{
    const data=await Cart.find();
    // console.log(data);
})
export default router;