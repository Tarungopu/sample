
import Product from '../models/Productmodel.js';

const getProducts =async(req,res)=>{
    // console.log(req.body)
    const data=await Product.find();

    res.json(data);
    

}
const getProductById = async(req,res)=>{
    const data= await Product.findById(req.params.id);
    res.json(data);

}
const deleteProductById=async(req,res)=>{
    const data= await Product.findByIdAndDelete(req.params.id)
    res.json(data);
}
export{
    getProducts,
    getProductById,
    deleteProductById
}